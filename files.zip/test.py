import glob
import os
txtfiles = []
for file in glob.glob("*.html"):
    txtfiles.append(file.replace(".html",""))

print(txtfiles.replace("','","</option><option>"))


